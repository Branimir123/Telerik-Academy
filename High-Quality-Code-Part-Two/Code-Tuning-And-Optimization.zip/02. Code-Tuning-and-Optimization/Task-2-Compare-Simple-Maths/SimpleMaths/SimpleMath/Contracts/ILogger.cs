﻿namespace SimpleMath.Contracts
{
    public interface ILogger
    {
        void Log(object obj);
    }
}
