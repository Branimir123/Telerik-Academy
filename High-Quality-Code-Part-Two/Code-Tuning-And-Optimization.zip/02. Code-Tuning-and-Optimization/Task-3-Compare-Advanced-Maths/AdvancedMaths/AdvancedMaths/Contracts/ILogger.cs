﻿namespace AdvancedMaths.Contracts
{
    public interface ILogger
    {
        void Log(object obj);
    }
}
